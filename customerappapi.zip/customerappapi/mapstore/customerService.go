package mapstore

import (
	"assignments/customerappapi/domain"
	"errors"
	"fmt"
)

// MapStore is an implementation of CustomerStore interface
type MapStore struct {
	// An in-memory store with a map
	// Use Customer.ID as the key of map
	store map[string]domain.Customer
}

// Factory method gives a new instance of MapStore
// This is for caller packages to create MapStore instances
func NewMapStore() *MapStore {
	return &MapStore{store: make(map[string]domain.Customer)}
}

// Implement interface methods of domain.CustomerStore

//Create(Customer) error
func (m *MapStore) Create(c domain.Customer) error {
	if c.ID == "" {
		return errors.New("cannot CREATE customer with blank ID ")
	} else {
		if _, ok := m.store[c.ID]; ok {
			return errors.New("ID already present, to CREATE new customor new ID should required ")
		}
	}
	m.store[c.ID] = c
	fmt.Println("Customer CREATED")
	return nil
}

//Update(string, Customer) error
func (m *MapStore) Update(id string, c domain.Customer) error {
	if id == "" {
		return errors.New("cannot UPDATE customer with blank ID ")
	} else {
		if _, ok := m.store[id]; !ok {
			return errors.New("cannot UPDATE as Customer id not present ")
		}
	}
	m.store[id] = c
	return nil
}

//Delete(string) error
func (m *MapStore) Delete(id string) error {
	if id == "" {
		return errors.New("cannot DELETE customer with blank ID ")
	} else {
		if _, ok := m.store[id]; !ok {
			return errors.New("cannot DELETE as Customer id not present")
		}
	}
	delete(m.store, id)
	return nil
}

//GetById(string) (Customer, error)
func (m *MapStore) GetById(id string) (domain.Customer, error) {
	if id == "" {
		return domain.Customer{}, errors.New("cannot GET customer as ID is blank")
	} else {
		if _, ok := m.store[id]; !ok {
			return domain.Customer{}, errors.New("cannot GET customer as ID is not present")
		}
	}
	return m.store[id], nil
}

//GetAll() ([]Customer, error)
func (m *MapStore) GetAll() ([]domain.Customer, error) {
	if len(m.store) < 1 {
		return nil, errors.New("no Customer exists to GET ")
	}
	cAll := []domain.Customer{}
	for _, val := range m.store {
		cAll = append(cAll, val)
	}
	return cAll, nil
}
