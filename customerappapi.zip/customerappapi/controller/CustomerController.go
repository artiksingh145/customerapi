package controller

import (
	"assignments/customerappapi/domain"
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"
)

type CustomerController struct {
	// Explicit dependency that hides dependent logic
	Store domain.CustomerStore // CustomerStore value
}

// Add a new customer
// HTTP Post - /customer
func (c *CustomerController) Post(w http.ResponseWriter, r *http.Request) {
	var cust domain.Customer
	// Decode the incoming json data to note struct
	err := json.NewDecoder(r.Body).Decode(&cust)
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	err1 := c.Store.Create(cust)
	if err1 != nil {
		http.Error(w, err1.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusCreated)
}

// GetAll customer
// HTTP Get - /customer
func (c *CustomerController) GetAll(w http.ResponseWriter, r *http.Request) {
	customers, err := c.Store.GetAll()
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	} else {
		j, err := json.Marshal(customers)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write(j)
	}
	// fmt.Println("all customers present are:")
	// for _, customer := range customers {
	// 	fmt.Println(customer)
	// }
}

// GET the customer by passing ID
// HTTP Get - /customer/{id}
func (c *CustomerController) Get(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	customer, err := c.Store.GetById(id)
	if err != nil {
		//fmt.Println("Error while GETTING customer by ID ", err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	} else {
		w.Header().Set("Content-Type", "application/json")
		j, err := json.Marshal(customer)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
		}
		w.WriteHeader(http.StatusOK)
		w.Write(j)
	}
	//fmt.Println("Customer by ID is: ", customer)
}

// UPDATE the customer by passing ID
// HTTP Put - /customer/{id}
//func (c *CustomerController) Put(id string, cust domain.Customer) {
func (c *CustomerController) Put(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]
	var cust domain.Customer

	err := json.NewDecoder(r.Body).Decode(&cust)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	// Update
	err1 := c.Store.Update(id, cust)

	if err1 != nil {
		http.Error(w, err1.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
	//fmt.Println("Customer has been UPDATED")
}

// DELETE the customer by passing ID
// HTTP Delete - /customer/{id}
func (c *CustomerController) Delete(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id := vars["id"]

	err := c.Store.Delete(id)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.WriteHeader(http.StatusNoContent)
	//fmt.Println("Customer has been DELETED")
}
