package main

import (
	"log"
	"net/http"

	"assignments/customerappapi/controller"
	"assignments/customerappapi/mapstore"
	"assignments/customerappapi/router"
)

func main() {
	controller := &controller.CustomerController{
		Store: mapstore.NewMapStore(),
	}
	r := router.InitializeRoutes(controller)
	server := &http.Server{
		Addr:    ":8080",
		Handler: r,
	}
	log.Println("Listening...")
	server.ListenAndServe() // Run the http server
}
